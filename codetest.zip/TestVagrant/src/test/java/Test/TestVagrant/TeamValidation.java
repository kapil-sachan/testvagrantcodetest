package Test.TestVagrant;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import junit.framework.Assert;


public class TeamValidation {
	int wk_keeper_count=0;
	int foreign_player_count=0;
	int indian__player_count=0;
	String arr []; 
	@Test
	void verifyData()
	{
		for(int i=0;i<arr.length;i++)
		{
			String player[] = arr[i].split(",");
			if(player[0].equals("India"))
			{
				indian__player_count++;
			}
			else
			{
				foreign_player_count++;
			}
			if(player[1].equals("Wicket-keeper"))
			{
				wk_keeper_count++;
			}
		}
		Assert.assertEquals(4, foreign_player_count);
		Assert.assertTrue("Atleast one wicket keeper", wk_keeper_count>=1);
		
	}
	
	
	@BeforeTest
	void readJson() throws IOException, ParseException
	{
		JSONParser jsonParser = new JSONParser();
		FileReader fileReader = new FileReader(".\\JSONfiles\\TeamData.json");
		Object obj = jsonParser.parse(fileReader);
		
	 JSONObject	teamDataJsonObj = (JSONObject) obj;
	 JSONArray teamJSONArray =(JSONArray)teamDataJsonObj.get("player");	
	 arr = new String[teamJSONArray.size()];
	 for(int i=0;i<teamJSONArray.size();i++)
	 {
		JSONObject players =(JSONObject) teamJSONArray.get(i);
		String p_country= (String)players.get("country");
		String p_role= (String)players.get("role");
		arr[i]= p_country+","+p_role;
		//System.out.println(arr[i]);
		
	 }
	 
		
	}
}
